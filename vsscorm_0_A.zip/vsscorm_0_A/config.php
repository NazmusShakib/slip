<?php 

$dbname = "my database name";
$dbhost = "my database host";
$dbuser = "my database username";
$dbpass = "my database password";

?>